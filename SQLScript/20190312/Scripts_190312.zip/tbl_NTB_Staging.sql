USE [ICBankSohar]
GO

/****** Object:  Table [dbo].[tbl_NTB_Staging]    Script Date: 10-03-2019 08:10:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_NTB_Staging](
	[CIF ID] [nvarchar](255) NULL,
	[ACCOUNT NUMBER] [nvarchar](255) NULL,
	[ACCOUNT NAME] [nvarchar](255) NULL,
	[ZONE] [nvarchar](255) NULL,
	[BRANCH] [nvarchar](255) NULL,
	[GENDER] [nvarchar](255) NULL,
	[ACCOUNT OPEN DATE] [nvarchar](255) NULL,
	[ACCOUNT ACTIVATION DATE] [nvarchar](255) NULL,
	[ACCOUNT CLOSE FLAG] [nvarchar](255) NULL,
	[ACCOUNT CLOSE DATE] [nvarchar](255) NULL,
	[SCHEME CODE] [nvarchar](255) NULL,
	[CURRENCY CODE] [nvarchar](255) NULL,
	[BALANCE IN ACCT CCY] [nvarchar](255) NULL,
	[BALANCE IN LOCAL CCY] [float] NULL,
	[NET INTEREST RATE] [nvarchar](255) NULL,
	[CUSTOMER CLASSIFICATION] [nvarchar](255) NULL,
	[ACCOUNT MANAGER ID] [nvarchar](255) NULL,
	[ACCOUNT MANAGER] [nvarchar](255) NULL,
	[EMPLOYER NAME] [nvarchar](255) NULL,
	[SOURCE PERSON ID] [nvarchar](255) NULL,
	[SOURCE PERSON NAME] [nvarchar](255) NULL,
	[LG code] [nvarchar](255) NULL,
	[LC code] [nvarchar](255) NULL,
	[RM code] [nvarchar](255) NULL,
	[Business Segment] [nvarchar](255) NULL,
	[Partner Segment] [nvarchar](255) NULL,
	[Promo Code] [nvarchar](255) NULL,
	[Wealth code] [nvarchar](255) NULL,
	[Date of Birth] [nvarchar](255) NULL,
	[Registered Salary] [float] NULL,
	[Current Salary Credit ] [nvarchar](255) NULL,
	[Current Salary Credit 1] [nvarchar](255) NULL,
	[Balance as per 27 Feb 2019] [float] NULL,
	[Average Monthly Balance] [float] NULL,
	[Balance for total CIF Feb ] [float] NULL,
	[Balance for total CIF 31 Jan 2019] [float] NULL,
	[FileId] [bigint] NULL
) ON [PRIMARY]

GO


