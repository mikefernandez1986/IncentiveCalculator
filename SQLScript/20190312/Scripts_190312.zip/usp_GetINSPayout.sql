USE [ICBankSohar]
GO

IF OBJECT_ID('usp_GetINSPayout', 'P') IS NOT NULL 
  DROP PROC dbo.usp_GetINSPayout; 
GO

/****** Object:  StoredProcedure [dbo].[usp_GetINSPayout]    Script Date: 17-02-2019 01:32:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


Create PROCEDURE [dbo].[usp_GetINSPayout]
AS
BEGIN  

	SELECT EMP_NO, EMP_NAME, PRODUCT, Achieved, TargetAchieved, TotalPoints, KPIRating, PropsedPayAmount as ProposedPayAmount,
	ActualPayAmount, RetainedLoyalityAmt, PAYOUTCODE 
	FROM tbl_INC_INS
	ORDER BY EMP_NO
	
END


GO



--exec usp_GetINSPayout
