USE [ICBankSohar]
GO

IF OBJECT_ID('usp_ProcessNTBData', 'P') IS NOT NULL 
  DROP PROC dbo.usp_ProcessINSData; 
GO

/****** Object:  StoredProcedure [dbo].[usp_ProcessNTBData]    Script Date: 04-03-2019 11:02:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




Create PROCEDURE [dbo].[usp_ProcessNTBData]
AS  
BEGIN  

	SET NOCOUNT ON;

	--truncate table tbl_NTB_Staging
	--select * from tbl_NTB_Staging


	/********** Select required columns from Staging table **************/
	
	--drop table #NTBTemp1;
	Select Convert(datetime, [ACCOUNT ACTIVATION DATE], 105) as AADate,  SUBSTRING(REPLACE(Upper([SCHEME CODE]), ' ', ''), 1, 1) as SchemeCode, REPLACE(Upper([CUSTOMER CLASSIFICATION]), ' ', '') as CC, 
	[LG code] as LG, [LC code] as LC, Convert(float, Replace([Current Salary Credit ], ',', '')) as Salary, [Average Monthly Balance] as AMB
	into #NTBTemp1
	from tbl_NTB_Staging
	where  ([LC code] is not null) or ([LG code] is not null)
		and (([SCHEME CODE] is not null) and (Len([Scheme Code]) > 0))
		
		

	/********* Identify Product ***********/

	--drop table #NTBTemp2;
	Select AADate,  LG, LC, Salary, AMB, SchemeCode, CC,
			(CASE 
				WHEN (CC in ('HNI', 'PB-PRIVILEGE')) THEN 'HNI'
				WHEN (CC in ('RETAILOTHERS', 'RETAILBUSINESS')) THEN 'MASS'
				ELSE Null
			END) as Segment,
			DATEADD(month, DATEDIFF(month, 0, AADate), 0) as M0OfAADate,
			DATEADD(month, DATEDIFF(month, -1, AADate), 0) as M1OfAADate
	into #NTBTemp2
	from #NTBTemp1

--select * from #NTBTemp2 order by productCode



	/********** Gets first day of business month being processed, which is previous month from current date ************/
	Declare @BusinessMonth datetime = DATEADD(mm, DATEDIFF(m,0,GETDATE())-1,0)


	/********* GET CA accounts which pass quality Check ***********/

	--drop table #NTBTemp3;
	Select AADate,  LG, LC, Salary, AMB, SchemeCode, CC, Segment, 10 as Points
	into #NTBTemp3
	from #NTBTemp2
	where Segment in ('HNI', 'MASS') 
		and SchemeCode = 'C' 
		and (@BusinessMonth = M1OfAADate)
		and (AMB >= 1000)

	--select * from #NTBTemp3
	

	/********* GET SA-HNI accounts that pass quality Check ***********/
	
	Insert into #NTBTemp3
	Select AADate,  LG, LC, Salary, AMB, SchemeCode, CC, Segment, 25 as Points
	from #NTBTemp2
	where Segment = 'HNI' 
		and SchemeCode = 'S' 
		and ((@BusinessMonth = M0OfAADate) or (@BusinessMonth = M1OfAADate))
		and ((Salary > 3500) or (AMB > 40000))
	
	
	/********* GET SA-Mass accounts that pass quality Check ***********/
	
	Insert into #NTBTemp3
	Select AADate,  LG, LC, Salary, AMB, SchemeCode, CC, Segment, 10 as Points
	from #NTBTemp2
	where Segment = 'MASS' 
		and SchemeCode = 'S' 
		and ((@BusinessMonth = M0OfAADate) or (@BusinessMonth = M1OfAADate))
		and ((Salary > 500) and (Salary < 1000))

	--select * from #NTBTemp3 where LC = 'NULL'



	/********* For LC: Group by LC and Product ***********/

	--drop table #NTBTemp4;
	Select LC, Segment, sum(Points) as TotalPoints
	into #NTBTemp4
	from #NTBTemp3 t1
	group by LC, Segment
	
	--select * from #NTBTemp4 order by LC


	/********* For LC: Get valid LCs and their targets based on product segment ***********/

	--drop table #NTBTemp5;
	Select LC, Segment, TotalPoints, 
			(CASE 
				WHEN (Segment = 'HNI') THEN t2.NTB_ALKhaas
				WHEN (Segment = 'MASS') THEN t2.NTB_Mass
				ELSE Null
			END) as EmpTarget
	into #NTBTemp5
	from #NTBTemp4 t1
	inner join tbl_EmpTargetInfo t2 on t1.LC = t2.Emp_no
	inner join tbl_EmpBasicInfo t3 on t1.LC = t3.Emp_No
	where Replace(Upper(t3.Incentive_Bonus), ' ', '') = 'INCENTIVE'

	
	--select * from #NTBTemp5 order by LC


	/********* For LC: Calculate Perf Score ***********/

	--drop table #NTBTemp6;
	Select LC, Segment, TotalPoints, EmpTarget,
		(TotalPoints*100/EmpTarget) as PerfScore
	into #NTBTemp6
	from #NTBTemp5
	where EmpTarget is not null

	--select * from #NTBTemp6 order by LC


	/********* For LC: Calculate KPI ***********/

	--drop table #NTBTemp7;
	Select LC, Segment, TotalPoints, EmpTarget, PerfScore,
				(CASE 
				WHEN (PerfScore >=  60  AND PerfScore <= 84) THEN 1
				WHEN (PerfScore >  84  AND PerfScore <= 99) THEN 2
				WHEN (PerfScore > 99  AND PerfScore <= 114) THEN 3
				WHEN (PerfScore >  114  AND PerfScore <= 125) THEN 4
				WHEN (PerfScore > 125) THEN 5
				ELSE 0
			END) as KPIRating
	into #NTBTemp7
	from #NTBTemp6
	where EmpTarget is not null

	--select * from #NTBTemp7 order by LC


	/********* For LC: Calculate Payout ***********/

	--drop table #NTBTemp8;
	Select LC, Segment, TotalPoints, EmpTarget, cast(PerfScore as decimal(18,2)) as PerfScore, KPIRating,
			(CASE 
				WHEN (KPIRating = 1) THEN TotalPoints*60.0/100
				WHEN (KPIRating = 2) THEN TotalPoints*80.0/100
				WHEN (KPIRating = 3) THEN TotalPoints*100.0/100
				WHEN (KPIRating = 4) THEN TotalPoints*120.0/100
				WHEN (KPIRating = 5) THEN TotalPoints*150.0/100
				ELSE 0
			END) as Payout
	into #NTBTemp8
	from #NTBTemp7

	--select * from #NTBTemp8 order by LC


	/********* For LG: Get valid LGs, Group by LG and calculate Payout ***********/

	--drop table #NTBTemp9;
	Select LG, sum(Points) as TotalPoints, sum(Points)/4.0 as Payout
	into #NTBTemp9
	from #NTBTemp3 t1
	inner join tbl_EmpBasicInfo t2 on t1.LC = t2.Emp_No
	where Replace(Upper(t2.Incentive_Bonus), ' ', '') = 'BONUS'
	group by LG
	
	--select * from #NTBTemp9 order by LG

	truncate table tbl_INC_NTB

	insert into tbl_INC_NTB
		select 
			LC,
			t2.EMP_NAME, 
			'NTB',
			TotalPoints,
			Iif((KPIRating > 0), 'Y', 'N'),
			totalpoints,
			KPIRating, 
			cast(Payout as decimal(18,2)),
			cast(Payout*75/100 as decimal(18,2)),
			cast(Payout*25/100 as decimal(18, 2)),
		'LC'
		from #NTBTemp8 t1
		inner join tbl_EmpBasicInfo t2 on t2.EMP_NO = t1.LC

	insert into tbl_INC_NTB
		select 
			LG, 
			t2.EMP_NAME, 
			'NTB',
			TotalPoints,
			'Y', 
			totalpoints, 
			3, 
			cast(Payout as decimal(18,2)),
			cast(Payout*75/100 as decimal(18,2)),
			cast(Payout*25/100 as decimal(18, 2)),
			'LG'
		from #NTBTemp9 t1
		inner join tbl_EmpBasicInfo t2 on t2.EMP_NO = t1.LG

	drop table #NTBTemp1
	drop table #NTBTemp2
	drop table #NTBTemp3
	drop table #NTBTemp4
	drop table #NTBTemp5
	drop table #NTBTemp6
	drop table #NTBTemp7
	drop table #NTBTemp8
	drop table #NTBTemp9


	--select * from tbl_INC_NTB order by Payoutcode, emp_no
END


GO


-- exec usp_ProcessNTBData

