USE [ICBankSohar]
GO

IF OBJECT_ID('usp_ProcessINSData', 'P') IS NOT NULL 
  DROP PROC dbo.usp_ProcessINSData; 
GO

/****** Object:  StoredProcedure [dbo].[usp_ProcessINSData]    Script Date: 04-03-2019 11:02:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




Create PROCEDURE [dbo].[usp_ProcessINSData]
AS  
BEGIN  

	SET NOCOUNT ON;

	/************************* LIFE : Calculate RTB: 70% pf Premium **************************************/
	select [Premium Amount]*70/100 as RTB, [Staff Id] as EMP_NO
	into #ITemp1
	from tbl_LifeInsurance_Staging cc

	/************************* Non-Life: Calculate RTB: 10% pf Premium **************************************/
	Insert into #ITemp1
	select [Premium]*10/100 as RTB, [Generated Lead Staff ID _(LG CODE)] as EMP_NO
	from tbl_NonLifeInsurance_Staging 
	where [Generated Lead Staff ID _(LG CODE)] is NOT Null


/************************** Get Emp targets for (LCs) Incentive plan employees **********************/
	select sum(RTB) as RTBSum, t1.EMP_NO as LC, CONVERT(float, REPLACE(t2.Bancassurance, ',', '')) as EmpTarget
	into #ITemp2
	from #ITemp1 t3
	inner join tbl_EmpBasicInfo t1 on t1.emp_no = t3.EMP_No
	inner join tbl_EmpTargetInfo t2 on t2.emp_no = t1.emp_no
	and LTrim(Rtrim(Upper(t1.[Incentive_Bonus]))) = 'INCENTIVE'
	group by t1.EMP_NO , t2.Bancassurance

	
	/************* Calculate points as 10% of RTB, Perf Score for (LC) Incentive plan employees ********/
	select RTBSum,  RTBSum/10 as TotalPoints, LC, EmpTarget,
				(t1.RTBSum*100/EmpTarget) as PerfScore 
	into #ITemp3
	 from #ITemp2 t1
	

	/************************** Calculate KPI rating from PerfScore for (LC) Incentive plan employees **********************/
	select LC,
			RTBSum,
			TotalPoints,
			EmpTarget,
			PerfScore, 
			(CASE 
				WHEN (PerfScore >=  60  AND PerfScore <= 84) THEN 1
				WHEN (PerfScore >  84  AND PerfScore <= 99) THEN 2
				WHEN (PerfScore > 99  AND PerfScore <= 114) THEN 3
				WHEN (PerfScore >  114  AND PerfScore <= 125) THEN 4
				WHEN (PerfScore > 125) THEN 5
				ELSE 0
			END) as KPIRating
	into #ITemp4
	from #ITemp3

	
	/************** Calculate Payout based on KPI Rating for (LC) Incentive plan employees ***********/
	select LC,
		RTBSum,
		TotalPoints,
		EmpTarget,
		PerfScore, 
		KPIRating,
		(CASE 
			WHEN (KPIRating = 1) THEN TotalPoints*60.0/100
			WHEN (KPIRating = 2) THEN TotalPoints*80.0/100
			WHEN (KPIRating = 3) THEN TotalPoints*100.0/100
			WHEN (KPIRating = 4) THEN TotalPoints*120.0/100
			WHEN (KPIRating = 5) THEN TotalPoints*150.0/100
			ELSE 0
		END) as Payout
	into #ITemp5
	from #ITemp4

	/************ Calculate Points as 10% of RTB & Payout as 25% of Points for (LGs) Bonus plan employees ***********/
	select sum(RTB) as RTBSum, sum(RTB/10) as TotalPoints, t1.Emp_NO as LG, 0 as EmpTarget, sum(RTB/(10*4)) as Payout
	into #ITemp6
	from #ITemp1 t2
	inner join tbl_EmpBasicInfo t1 on t1.emp_no = t2.EMP_NO
	and LTrim(Rtrim(Upper(t1.[Incentive_Bonus]))) = 'BONUS'
	group by t1.Emp_NO


	truncate table tbl_INC_INS


	/************ Insert LC information into INC_Life table ***********/
	insert into tbl_INC_INS
		select 
			LC,
			t1.EMP_NAME, 
			'INS',
			RTBSum,
			Iif((KPIRating > 0), 'Y', 'N'),
			totalpoints,
			KPIRating, 
			cast(Payout as decimal(18,2)),
			cast(Payout*75/100 as decimal(18,2)),
			cast(Payout*25/100 as decimal(18, 2)),
		'LC'
		from #ITemp5 cc
		inner join tbl_EmpBasicInfo t1 on t1.EMP_NO = cc.LC

	/************ Insert LG information into INC_Life table ***********/
	insert into tbl_INC_INS
		select 
			LG,
			t1.EMP_NAME, 
			'INS',
			RTBSum,
			'Y',
			totalpoints,
			3, 
			cast(Payout as decimal(18,2)),
			cast(Payout*75/100 as decimal(18,2)),
			cast(Payout*25/100 as decimal(18, 2)),
		'LG'
		from #ITemp6 cc
		inner join tbl_EmpBasicInfo t1 on t1.EMP_NO = cc.LG

		--select * from tbl_inc_life order by PAYOUTCODE, emp_no

	drop table #ITemp1
	drop table #ITemp2
	drop table #ITemp3
	drop table #ITemp4
	drop table #ITemp5
	drop table #ITemp6

END


GO


-- exec usp_ProcessINSData

