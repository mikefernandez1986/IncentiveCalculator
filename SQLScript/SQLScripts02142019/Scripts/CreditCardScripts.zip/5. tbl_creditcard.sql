USE [ICBankSohar]
GO

/****** Object:  Table [dbo].[tbl_creditcard]    Script Date: 14-02-2019 09:56:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_creditcard](
	[Card No ] [nvarchar](255) NULL,
	[Type_of_Card] [nvarchar](255) NULL,
	[Account_No ] [nvarchar](255) NULL,
	[Card Holder Name] [nvarchar](255) NULL,
	[CIF ] [nvarchar](255) NULL,
	[Sol ID] [nvarchar](255) NULL,
	[Card_Issue_Date] [datetime] NULL,
	[Card_Active_Date] [datetime] NULL,
	[LG] [nvarchar](255) NULL,
	[LC ] [nvarchar](255) NULL,
	[RM] [nvarchar](255) NULL,
	[F12] [nvarchar](255) NULL
) ON [PRIMARY]

GO


