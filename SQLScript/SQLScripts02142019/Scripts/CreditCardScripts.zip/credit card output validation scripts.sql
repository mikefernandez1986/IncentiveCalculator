exec dbo.usp_ProcessCreditCardData_new

select * from tbl_creditcardpayoutdetails_temp order by payout_code, EMP_no

select t1.* , t2.perfscore, 
(CASE 
				WHEN (KPIRating = 1) THEN 60
				WHEN (KPIRating = 2) THEN 80
				WHEN (KPIRating = 3) THEN 100
				WHEN (KPIRating = 4) THEN 120
				WHEN (KPIRating = 5) THEN 150
				ELSE 0
			END) as PayoutPercentage 
from tbl_creditcardpayoutdetails_temp t1
inner join CCLCTemp4 t2 on t1.emp_no = t2.lc
Union
select t1.* , 0 as PerfScore, 
25 as PayoutPercentage 
from tbl_creditcardpayoutdetails_temp t1
where Payout_code = 'LG'

