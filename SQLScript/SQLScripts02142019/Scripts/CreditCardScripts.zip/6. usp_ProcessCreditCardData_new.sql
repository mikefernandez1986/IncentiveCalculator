USE [ICBankSohar]
GO

IF OBJECT_ID('usp_ProcessCreditCardData_new', 'P') IS NOT NULL 
  DROP PROC dbo.usp_ProcessCreditCardData_new; 
GO

/****** Object:  StoredProcedure [dbo].[usp_ProcessCreditCardData_new]    Script Date: 13-02-2019 11:54:57 ******/
SET ANSI_NULLS ON

SET QUOTED_IDENTIFIER ON
GO



Create PROCEDURE [dbo].[usp_ProcessCreditCardData_new]
AS  
BEGIN  

	/**** Get card data, respective points and Quality Month based on product code/type ************/
	/****************************************************************************************/
	select [Type_Of_Card], [Card_Issue_Date], [Card_Active_Date], LC, LG,
	pm.ProductCode, 
	pm.ProductPoints,
	qm.QualityMonth,
		(CASE 
			WHEN (QualityMonth = 'M0') THEN DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,[Card_Issue_Date])+1,0))
			WHEN (QualityMonth = 'M2') THEN DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,[Card_Issue_Date])+3,0))
			ELSE DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,[Card_Issue_Date])+2,0)) /**Default of M0**/
		END) as QualityDate
	into #CCTemp1
	from tbl_CreditCard cc
	inner join tbl_ProductMaster pm on RTRIM(LTRIM(Upper(cc.[Type_of_Card]))) = pm.ProductCode
	inner join tbl_RuleEngineMaster rm on pm.ProductId = rm.Productid
	inner join tbl_PayoutQualityMaster qm on rm.QualityId = qm.QualityId

select * from #CCTemp1

	/**** Filter out invalid card data based on Quality Month check ************/
	/****************************************************************************************/
	select [Type_Of_Card], LC, LG, ProductPoints,
	ProductCode
	into #CCTemp2
	from #CCTemp1 
	where [Card_Active_Date] <= QualityDate

select * from #CCTemp2
	
	/**** Get total # of cards and points, for each LC ************/
	/****************************************************************************************/
	select 
		LC,
		t2.[credit_card] as EmpTarget, 
		count(*) as TotalCards, 
		sum(ProductPoints) as TotalPoints
	into #CCLCTemp1
	from 
		#CCTemp2 t1
		inner join tbl_staffmaster t2 on emp_no_str = t1.LC
	where RTrim(LTrim(LC)) != ''
		and  LTrim(Rtrim(Upper(t2.Incentive_Bonus))) = 'INCENTIVE'
		and t2.[credit_card] is not Null
	group by  LC, t2.[credit_card]

select * from #CCLCTemp1 order by LC

	/**** Get total # of cards and points, for each LG ************/
	/****************************************************************************************/
	select 
		LG, 
		count(*) as TotalCards, 
		sum(ProductPoints) as TotalPoints
	into #CCLGTemp1
	from 
		#CCTemp2 t1
		inner join tbl_staffmaster t2 on emp_no_str = t1.LG
	where RTrim(LTrim(LG)) != ''
		and  LTrim(Rtrim(Upper(t2.Incentive_Bonus))) = 'BONUS'
	group by  LG

select * from #CCLGTemp1 order by LG
	

	/**** Get Target and calculate performance score for the LC ************/
	/****************************************************************************************/
	select LC,
			TotalCards,
			TotalPoints,
			EmpTarget,
			(t1.TotalCards*100/EmpTarget) as PerfScore 
	into #CCLCTemp2
	from #CCLCTemp1 t1

select * from #CCLCTemp2 order by LC
	

	/**** Calculate KPI for the LC ************/
	/****************************************************************************************/
	select LC,
			TotalCards,
			TotalPoints,
			EmpTarget,
			PerfScore, 
			(CASE 
				WHEN (PerfScore >=  60  AND PerfScore <= 84) THEN 1
				WHEN (PerfScore >  84  AND PerfScore <= 99) THEN 2
				WHEN (PerfScore > 99  AND PerfScore <= 114) THEN 3
				WHEN (PerfScore >  114  AND PerfScore <= 125) THEN 4
				WHEN (PerfScore > 125) THEN 5
				ELSE 0
			END) as KPIRating
	into #CCLCTemp3
	from #CCLCTemp2

	select * from #CCLCTemp3 order by LC


	/**** Calculate Payout for the LC ************/
	/****************************************************************************************/
	select LC,
			TotalCards,
			TotalPoints,
			EmpTarget,
			PerfScore, 
			KPIRating,
			(CASE 
				WHEN (KPIRating = 1) THEN TotalPoints*60.0/100
				WHEN (KPIRating = 2) THEN TotalPoints*80.0/100
				WHEN (KPIRating = 3) THEN TotalPoints*100.0/100
				WHEN (KPIRating = 4) THEN TotalPoints*120.0/100
				WHEN (KPIRating = 5) THEN TotalPoints*150.0/100
				ELSE 0
			END) as Payout
	into #CCLCTemp4
	from #CCLCTemp3
	--where KPIRating > 0

	select * from #CCLCTemp4 order by LC


	/**** Calculate Payout for the LG ************/
	/****************************************************************************************/
	select LG,
			0 as EmpTarget,
			TotalCards,
			TotalPoints,
			(TotalPoints*25.0/100) as Payout
	into #CCLGTemp2
	from #CCLGTemp1 t1

	select * from #CCLGTemp2 order by LG

		
	truncate table tbl_creditcardpayoutdetails_temp

	insert into tbl_creditcardpayoutdetails_temp
		select 
			LC,
			sm.EMP_NAME, 
			'CARD',
			EmpTarget,
			TotalCards,
			Iif((KPIRating > 0), 'Y', 'N'),
			totalpoints,
			KPIRating, 
			cast(Payout as decimal(18,2)),
			cast(Payout*75/100 as decimal(18,2)),
			cast(Payout*25/100 as decimal(18, 2)),
		'LC'
		from #CCLCTemp4 cc
		inner join tbl_staffmaster sm on sm.EMP_NO_str = cc.LC

	insert into tbl_creditcardpayoutdetails_temp
		select 
			LG, 
			sm.EMP_NAME, 
			'CARD',
			0,
			TotalCards, 
			'Y', 
			totalpoints, 
			3, 
			cast(Payout as decimal(18,2)),
			cast(Payout*75/100 as decimal(18,2)),
			cast(Payout*25/100 as decimal(18, 2)),
			'LG'
		from #CCLGTemp2 cc
		inner join tbl_staffmaster sm on sm.EMP_NO_str = cc.LG

	drop table CCLCTemp3

	insert into CCLCTemp3
	select * from #CCLCTemp3

	drop table #CCTemp1
	drop table #CCTemp2
	drop table #CCLCTemp1
	drop table #CCLCTemp2
	drop table #CCLCTemp3
	drop table #CCLCTemp4
	drop table #CCLGTemp1
	drop table #CCLGTemp2

END  

GO
