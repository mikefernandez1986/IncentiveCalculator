declare @M1QualityId int

select @M1QualityId = qualityid from tbl_PayoutQualityMaster where QualityReqAmount is null and QualityMonth = 'M1'

if (@M1QualityId is null)
begin
	insert into tbl_PayoutQualityMaster values (null, 'M1')
	set @M1QualityId = @@IDENTITY
end

declare @ProductId int

insert into [tbl_ProductMaster] values ('CCInfinity', 'INFINITE', 'Credit Card Infinity', null, 20)
Set @ProductId = @@IDENTITY
insert into tbl_RuleEngineMaster values (@ProductId, @M1QualityId, null, 1)

insert into [tbl_ProductMaster] values ('CCGold', 'GOLD', 'Credit Card Gold', null, 5)
Set @ProductId = @@IDENTITY
insert into tbl_RuleEngineMaster values (@ProductId, @M1QualityId, null, 1)

insert into [tbl_ProductMaster] values ('CCSignature', 'SIGNATURE', 'Credit Card Signature', null, 15)
Set @ProductId = @@IDENTITY
insert into tbl_RuleEngineMaster values (@ProductId, @M1QualityId, null, 1)

insert into [tbl_ProductMaster] values ('CCPlatinum', 'PLATINUM', 'Credit Card Platinum', null, 12)
Set @ProductId = @@IDENTITY
insert into tbl_RuleEngineMaster values (@ProductId, @M1QualityId, null, 1)

insert into [tbl_ProductMaster] values ('CCCorporateCredit', 'CORPORATE', 'Credit Card Corporate Credit', null, 20)
Set @ProductId = @@IDENTITY
insert into tbl_RuleEngineMaster values (@ProductId, @M1QualityId, null, 1)


