/************ Recreate tbl_RuleEngineMaster *******/
/****** Object:  Table [dbo].[tbl_RuleEngineMaster]    Script Date: 01/23/2019 10:18:40 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tbl_RuleEngineMaster](
	[RuleEngineID] [int] IDENTITY(1,1) NOT NULL,
	[Productid] [int] NULL,
	[QualityId] [int] NULL,
	[CaveatId] [int] NULL,
	[FrequencyId] [int] NULL,
 CONSTRAINT [PK_tbl_RuleEngineMaster] PRIMARY KEY CLUSTERED 
(
	[RuleEngineID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET IDENTITY_INSERT [dbo].[tbl_RuleEngineMaster] ON 
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (1, 1, 1, 1, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (2, 2, 2, 2, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (3, 3, 3, 3, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (4, 4, 1, 1, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (5, 5, 4, 4, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (6, 6, 9, 7, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (7, 7, 10, 8, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (8, 8, 11, 9, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (9, 9, 5, 10, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (10, 10, 3, 3, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (11, 11, 3, 3, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (13, 13, 8, 11, 1)
INSERT [dbo].[tbl_RuleEngineMaster] ([RuleEngineID], [Productid], [QualityId], [CaveatId], [FrequencyId]) VALUES (14, 14, 8, 11, 1)
SET IDENTITY_INSERT [dbo].[tbl_RuleEngineMaster] OFF
GO
