USE [ICBankSohar]
GO

/****** Object:  Table [dbo].[tbl_CreditCardPayoutDetails_temp]    Script Date: 14-02-2019 09:54:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_CreditCardPayoutDetails_temp](
	[EMP_NO] [nvarchar](25) NOT NULL,
	[EMP_NAME] [nvarchar](255) NULL,
	[PRODUCT] [nvarchar](255) NOT NULL,
	[TARGET] [int] NULL,
	[ACHIEVED] [int] NULL,
	[TARGET_ACHEIVED] [char](1) NOT NULL,
	[TOTAL_POINTS] [int] NOT NULL,
	[KPI_RATING] [float] NOT NULL,
	[PROPOSED_PAYOUT_AMT] [float] NOT NULL,
	[ACTUAL_PAYOUT_AMT] [float] NOT NULL,
	[RETAINED_LOYALTY_AMT] [float] NOT NULL,
	[PAYOUT_CODE] [nvarchar](5) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


