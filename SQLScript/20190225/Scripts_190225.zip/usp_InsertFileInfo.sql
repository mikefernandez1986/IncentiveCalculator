USE [ICBankSohar]
GO


IF OBJECT_ID('usp_InsertFileInfo', 'P') IS NOT NULL 
  DROP PROC dbo.usp_InsertFileInfo; 
GO

/****** Object:  StoredProcedure [dbo].[usp_InsertFileInfo]    Script Date: 17-02-2019 22:08:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================

-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertFileInfo] 
	(
		@FileName Varchar(100),
		@FileType Varchar(10)
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    INSERT INTO tbl_FileUploadDetails
	([FileName], FileType, [Status], LastUpdated_Ts)	VALUES	(@FileName, @FileType, 0, GETDATE())
	SELECT SCOPE_IDENTITY()as FileId
END



GO


