USE [ICBankSohar]
GO

IF OBJECT_ID('dbo.tbl_FileUploadDetails', 'U') IS NOT NULL 
  DROP TABLE dbo.tbl_FileUploadDetails; 
GO

/****** Object:  Table [dbo].[tbl_FileUploadDetails]    Script Date: 17-02-2019 00:53:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_FileUploadDetails](
	[FileId] [bigint] IDENTITY(1,1) NOT NULL,
	[FileName] [nvarchar](100) NULL,
	[FileType] [nvarchar](10) NULL,
	[DateCreated] [datetime] NULL,
	[IsProcessed] [bit] NULL,
	[LastUpdated_Ts] [datetime] NULL,
	[Status] [int] NULL,
 CONSTRAINT [PK_tbl_FileUploadDetails] PRIMARY KEY CLUSTERED 
(
	[FileId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[tbl_FileUploadDetails] ADD  CONSTRAINT [DF_tbl_FileUploadDetails_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO


