USE [ICBankSohar]
GO

IF OBJECT_ID('usp_UpdateFileInfo', 'P') IS NOT NULL 
  DROP PROC dbo.usp_UpdateFileInfo; 
GO


/****** Object:  StoredProcedure [dbo].[usp_UpdateFileInfo]    Script Date: 17-02-2019 22:48:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



Create PROCEDURE [dbo].[usp_UpdateFileInfo]
(
	@FileId bigint,
	@Status int
)
AS  
BEGIN
	  update dbo.tbl_FileUploadDetails
	  set Status = @Status,
	  LastUpdated_Ts = GETDATE()
	  where FileId = @FileId
END

GO


