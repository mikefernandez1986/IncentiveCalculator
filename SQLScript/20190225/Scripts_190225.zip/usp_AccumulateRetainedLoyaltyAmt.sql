USE [ICBankSohar]
GO

IF OBJECT_ID('usp_AccumulateRetainedLoyaltyAmt', 'P') IS NOT NULL 
  DROP PROC dbo.usp_AccumulateRetainedLoyaltyAmt; 
GO

/****** Object:  StoredProcedure [dbo].[usp_AccumulateRetainedLoyaltyAmt]    Script Date: 17-02-2019 01:32:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




Create PROCEDURE [dbo].[usp_AccumulateRetainedLoyaltyAmt]
(
	@IsReprocess bit
)
AS  
BEGIN  
	Declare @BakCount int

	If (@IsReprocess = 1)
	BEGIN
		/************ Restore previous Amounts from backup table ***************/
		Set @BakCount = (select count(1) from  tbl_Ret_Loyalty_Bak)
		If (@BakCount > 0)
			BEGIN
				Truncate table tbl_Ret_Loyalty
				Insert into tbl_Ret_Loyalty select * from tbl_Ret_Loyalty_Bak
			END
	END
	ELSE
	BEGIN
		/************ Copy amounts to backup table ***************/
			Truncate table tbl_Ret_Loyalty_Bak
			Insert into tbl_Ret_Loyalty_Bak select * from tbl_Ret_Loyalty
	END

	/************ Get summation of Retained amounts across all products ***************/
	SELECT a.* INTO #CumulativePayout
	from
	(select
	 Emp_No, SUM(ISNULL(RetainedLoyalityAmt, 0))  AS RetainedLoyalityAmtSum
	 from vw_CumulativePayout
	GROUP BY Emp_No) a
	
	/************ Accumulate Retained amounts to tbl_Ret_Loyalty table ***************/
	MERGE tbl_Ret_Loyalty t 
	USING #CumulativePayout s
	ON s.emp_no = t.emp_no 
	WHEN MATCHED
		THEN UPDATE SET 
			t.Cum_RetLoyalityAmt = t.Cum_RetLoyalityAmt + s.RetainedLoyalityAmtSum,
			t.LastUpdated_Ts = GETDATE()
	WHEN NOT MATCHED BY TARGET 
		THEN INSERT (EMP_NO, Cum_RetLoyalityAmt, LastUpdated_Ts)
			 VALUES (s.EMP_No, s.RetainedLoyalityAmtSum, GETDATE());

END  


GO

-- exec usp_AccumulateRetainedLoyaltyAmt 0



--select t1.EMP_NO, t1.Cum_RetLoyalityAmt as t1, t2.Cum_RetLoyalityAmt as t2
-- from tbl_Ret_Loyalty t1
--inner join tbl_Ret_Loyalty_bak t2 on t1.EMP_NO = t2.emp_no





