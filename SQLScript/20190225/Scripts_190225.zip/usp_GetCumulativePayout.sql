USE [ICBankSohar]
GO

IF OBJECT_ID('usp_GetCumulativePayout', 'P') IS NOT NULL 
  DROP PROC dbo.usp_GetCumulativePayout; 
GO

/****** Object:  StoredProcedure [dbo].[usp_GetCumulativePayout]    Script Date: 17-02-2019 01:32:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




Create PROCEDURE [dbo].[usp_GetCumulativePayout]
AS
BEGIN

	SELECT 
		Emp_No, 
		EMP_Name, 
		'ALL' AS PRODUCT, 
		CONVERT (decimal(16,2), AVG(CAST(KPIRating AS float))) as KPIRating, 
		SUM(ISNULL(TotalPoints, 0)) as TotalPoints ,
		SUM(ISNULL(PropsedPayAmount, 0)) as PropsedPayAmount,
		SUM(ISNULL(ActualPayAmount, 0)) AS ActualPayAmount,
		SUM(ISNULL(RetainedLoyalityAmt, 0))  AS RetainedLoyaltyAmt 
	FROM vw_CumulativePayout
	GROUP BY Emp_No, EMP_Name
	ORDER BY emp_no

	--SELECT * FROM  #FinalTemp order by emp_no 

	
END

GO

-- exec usp_GetCumulativePayout