CREATE VIEW dbo.[vw_CumulativePayout] AS


	SELECT * FROM tbl_INC_CASA
	UNION ALL 
	SELECT * FROM tbl_INC_LOAN
	UNION ALL
	SELECT * FROM tbl_INC_CARD
	UNION ALL
	SELECT * FROM tbl_INC_LIFE
	UNION ALL
	SELECT * FROM tbl_INC_NLIFE;
	
	
	
	--select * from [vw_CumulativePayout]