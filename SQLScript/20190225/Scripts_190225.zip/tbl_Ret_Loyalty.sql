USE [ICBankSohar]
GO

/****** Object:  Table [dbo].[tbl_Ret_Loyalty]    Script Date: 22-02-2019 22:42:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_Ret_Loyalty](a
	[EMP_NO] [nvarchar](255) NOT NULL,
	[Prev_RetLoyalityAmt] float NULL,
	[Cum_RetLoyalityAmt] float NULL,
	[LastUpdated_TS] DateTime NULL
) ON [PRIMARY]

GO


