USE [ICBankSohar]
GO

/****** Object:  Table [dbo].[tbl_Ret_Loyalty_Bak]    Script Date: 25-02-2019 16:29:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_Ret_Loyalty_Bak](
	[EMP_NO] [nvarchar](255) NOT NULL,
	[Cum_RetLoyalityAmt] [float] NULL,
	[LastUpdated_TS] [datetime] NULL
) ON [PRIMARY]

GO


